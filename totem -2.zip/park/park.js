// Variables principales
const buttons = document.querySelectorAll('.day-buttons button');
const carouselImages = document.querySelector('.carousel-images');
const images = document.querySelectorAll('.carousel-images img');
const totalImages = images.length;

let currentIndex = 0; // Índice actual del carrusel
let intervalId; // ID del intervalo del carrusel automático

// Función para cambiar de imagen en el carrusel
function changeSlide(index) {
  // Verifica si el índice está dentro de los límites, si no, ajusta de manera cíclica
  if (index < 0) {
    currentIndex = totalImages - 1; // Si es menor a 0, ir a la última imagen
  } else if (index >= totalImages) {
    currentIndex = 0; // Si excede el total, volver a la primera imagen
  } else {
    currentIndex = index; // Actualiza el índice actual
  }

  // Mueve el carrusel a la imagen correspondiente
  const offset = -14.29 * currentIndex; // Calcula el desplazamiento
  carouselImages.style.transform = `translateX(${offset}%)`;

  // Actualiza la clase activa del botón para reflejar el estado actual
  buttons.forEach((btn, btnIndex) => {
    btn.classList.toggle('active', btnIndex === currentIndex);
  });
}

// Función para iniciar el carrusel automático
function startCarousel() {
  intervalId = setInterval(() => {
    changeSlide(currentIndex + 1); // Avanza al siguiente índice
  }, 10000); // Cambia cada 10 segundos
}

// Función para detener el carrusel automático
function stopCarousel() {
  clearInterval(intervalId);
}

// Asigna eventos de clic a los botones
buttons.forEach((button, index) => {
  button.addEventListener('click', () => {
    stopCarousel(); // Detiene el carrusel automático al hacer clic
    changeSlide(index); // Cambia a la imagen seleccionada por el botón
    startCarousel(); // Reinicia el carrusel automático
  });
});

// Configuración inicial al cargar la página
window.addEventListener('load', () => {
  changeSlide(0); // Muestra la primera imagen al cargar
  startCarousel(); // Inicia el carrusel automático
});

// Redirección automática al inicio después de 30 segundos  
let timeout;  

function resetTimeout() {  
  clearTimeout(timeout);  
  timeout = setTimeout(() => {  
    window.location.href = "../index.html";  
  }, 30000); // 30 segundos  
}  

// Reinicia el temporizador en cada interacción del usuario  
document.addEventListener("mousemove", resetTimeout);  
document.addEventListener("keydown", resetTimeout);  
document.addEventListener("click", resetTimeout);  
document.addEventListener("touchstart", resetTimeout);  

// Inicia el temporizador al cargar la página  
resetTimeout();