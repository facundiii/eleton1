// Variables
const carouselImages = document.querySelector('.carousel-images');
let currentIndex = 1;

// Función para cambiar entre imágenes
function changeSlide() {
  currentIndex = (currentIndex + 1) % 2; // Alterna entre 0 y 1
  const offset = -50 * currentIndex; // Calcula el desplazamiento
  carouselImages.style.transform = `translateX(${offset}%)`;
}

// Inicia el carrusel automático
setInterval(changeSlide, 12000); // Cambia cada 5 segundos

// Redirección automática al inicio después de 30 segundos  
let timeout;  

function resetTimeout() {  
  clearTimeout(timeout);  
  timeout = setTimeout(() => {  
    window.location.href = "../index.html";  
  }, 38000); // 30 segundos  
}  

// Reinicia el temporizador en cada interacción del usuario  
document.addEventListener("mousemove", resetTimeout);  
document.addEventListener("keydown", resetTimeout);  
document.addEventListener("click", resetTimeout);  
document.addEventListener("touchstart", resetTimeout);  

// Inicia el temporizador al cargar la página  
resetTimeout();